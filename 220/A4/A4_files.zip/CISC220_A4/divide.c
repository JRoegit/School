#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int divide(int x, int y, int *rem, double *quot) {

}

