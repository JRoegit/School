#include <stdio.h>

/*
 * Prints the values of a on a single line with no space between
 * the values. Prints a newline character after printing all of
 * the array values.
 * 
 * Values are printed left to right starting from a[0] and ending with a[7].
 */
void print(int a[static 8]) {
}

/*
 * Translates a string str consisting of '0' and '1' characters
 * into an array bin consisting of 0 and 1 integer values. For
 * example, the string "00000001" results in the array bin
 * having the values bin[0] = 0, bin[1] = 0, ..., bin[7] = 1.
 */
void tobinary(char str[static 8], int bin[static 8]) {
}

/*
 * Sums the 8-digit binary values x and y storing the result
 * in z. The sum is computed using the standard long
 * addition algorithm from grade school.
 */
int sum(int x[static 8], int y[static 8], int z[static 8]) {
}

